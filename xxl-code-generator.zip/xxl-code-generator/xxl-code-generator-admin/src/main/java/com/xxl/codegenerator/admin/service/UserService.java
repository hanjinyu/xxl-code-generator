package com.xxl.codegenerator.admin.service;

/**
 * 用户接口
 * @author Administrator
 *
 */
public interface UserService {

}
