package com.xxl.codegenerator.admin.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.xxl.codegenerator.admin.core.model.UserInfo;
import com.xxl.codegenerator.admin.exception.UserException;

@Controller
public class LoginController {
	
	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	//跳转登陆界面
	@RequestMapping(value = "/user/login", method = {RequestMethod.GET})
	public String loginForward() {
		return "";
	}
	
	//登陆信息提交,跳转到index
	@RequestMapping(value = "/user/loginSubmit", method = {RequestMethod.POST})
	public String loginSubmit(@RequestBody UserInfo userInfo) {
		try {
			
		}catch(UserException ue) {
			ue.printStackTrace();
			logger.error(ue.getMessage());
		}
		return "";
	}
	
}
